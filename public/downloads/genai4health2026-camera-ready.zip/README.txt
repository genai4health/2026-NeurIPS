GenAI4Health @ NeurIPS 2026 - Camera-ready LaTeX starter

QUICK START (OVERLEAF)
1. New Project > Upload Project: upload this ZIP.
2. Select main.tex as the main document and pdfLaTeX as the compiler.
3. Recompile, then replace the example title, authors, abstract, and paper.
4. Keep neurips_2026.sty and genai4health_2026.sty beside main.tex.

EXISTING PAPER
Replace your existing \usepackage[...]{neurips_2026} line with:
  \usepackage{genai4health_2026}
Do not load neurips_2026 a second time or combine final with preprint.
Copy both .sty files from this ZIP into your project. Restore author names,
affiliations, and acknowledgments. Keep the \maketitle command.
If you customize natbib options, pass them before loading the style, e.g.:
  \PassOptionsToPackage{numbers,sort&compress}{natbib}
Do not use an older neurips_2025.sty or add manual footer/geometry overrides.

LOCAL BUILD (TEX LIVE / MACTEX)
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  bibtex main
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
Alternative: latexmk -pdf main.tex
Alternative: tectonic main.tex
The plainnat bibliography style is supplied by standard TeX distributions;
there is no required neurips_2026.bst file.

WHAT IS PRECONFIGURED
- Official NeurIPS 2026 style, loaded with [dblblindworkshop,final].
- Visible author names and affiliations; no review line numbers.
- Official margins and typography; no changes to neurips_2026.sty.
- First-page workshop notice, automatically wrapped to the text width:
  GenAI for Health Workshop @ NeurIPS 2026, Sydney.
The separate genai4health_2026.sty overrides only the notice text using the
official first-page notice mechanism. This is a workshop-specific starter,
not a NeurIPS main-conference camera-ready template.

FILES
main.tex                  Editable example paper (main document)
references.bib            Example BibTeX reference
neurips_2026.sty           Unmodified official style
genai4health_2026.sty      Workshop final-mode and notice configuration
main.pdf                  Compiled example for visual comparison
README.txt                These instructions
SOURCE.txt                Official source and provenance

Use the current workshop website for page limits and submission policies:
https://genai4health.github.io/2026-NeurIPS/
The example contains no NeurIPS Paper Checklist, consistent with the
workshop's published requirements. Delete all example content before use.
